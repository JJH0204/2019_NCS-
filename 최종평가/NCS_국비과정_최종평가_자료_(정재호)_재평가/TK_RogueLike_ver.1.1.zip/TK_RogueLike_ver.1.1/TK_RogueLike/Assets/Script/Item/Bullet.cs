﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : Item
{
    public Vector3 startForc;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag != "Player")
        {
            Rigidbody2D thisRigid = this.gameObject.GetComponent<Rigidbody2D>();
            thisRigid.AddForce(-startForc);
            if (collision.gameObject.tag == "Monster")
            {
                Monster MonsterChar = collision.gameObject.GetComponent<Monster>();
                MonsterChar.SetHP(MonsterChar.GetHP() - 10);
            }
            Destroy(this.gameObject);
        }
    }
}
