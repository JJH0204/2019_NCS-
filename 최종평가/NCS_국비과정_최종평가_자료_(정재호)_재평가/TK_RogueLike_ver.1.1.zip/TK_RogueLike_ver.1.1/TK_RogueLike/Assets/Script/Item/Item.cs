﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    public string m_sItemName;
    public int m_nHaveCount;
    public int m_nMaxHaveCount;

    public float m_fHp;
    public float m_fDef;
    public float m_fPower;
    public float m_fSpeed;
    public float m_fAtkSpeed;
    public Item() { }
    public Item(string _name, int _havecount, int _maxhave, float _hp, float _def, float _power, float _speed, float _atkspeed)
    {
        m_sItemName = _name ;
        m_nHaveCount = _havecount;
        m_nMaxHaveCount= _maxhave;

        m_fHp=_hp;
        m_fDef = _def;
        m_fPower = _power;
        m_fSpeed = _speed;
        m_fAtkSpeed = _atkspeed;
    }
    public Item(float _hp, float _def, float _power, float _speed, float _atkspeed)
    {

    }

}
