﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    //게임 진행 관리
    public SponManager MonSpon;
    public ItemManager ItemManager;
    
    
    public bool isGameOver;
    
    
    
    
    void Start()
    {
        
        
    }

 
    void Update()
    {
        MonSpon.SponMonster();
        if (!MonSpon.StillAliveMon())
        {
            ItemManager.BoxRander();
        }
        //if(isBoxRander)
        //{
        //    Debug.Log("GameOver");
        //}
    }
}
