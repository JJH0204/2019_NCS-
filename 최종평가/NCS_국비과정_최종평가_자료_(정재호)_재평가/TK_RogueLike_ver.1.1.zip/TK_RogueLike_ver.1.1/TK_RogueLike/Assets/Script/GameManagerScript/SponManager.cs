﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SponManager : MonoBehaviour
{
    public List<GameObject> m_lCreatPos;
    public GameObject m_gCreatObj;
    public int m_nCreatCount;
    private GameObject[] m_lMonsters;
    private List<int> RandIndex;
    private bool isSpon;

    public SponManager()
    {
        isSpon = false;
    }

    private bool ListSearch(int Data)
    {
        if (RandIndex.Count != 0)
        {
            for (int count = 0; count < RandIndex.Count; count++)
            {
                if (RandIndex[count] == Data)
                    return false;
            }
        }
        return true;
    }
    private int ChoiceRand()
    {
        while (true)
        {
            int nIndex = (int)Random.Range(0f, 4f);
            if (ListSearch(nIndex))
            {
                RandIndex.Add(nIndex);
                return nIndex;
            }
        }
    }
    public void SponMonster()
    {
        if (isSpon == true) return; 
        m_lMonsters = new GameObject[m_nCreatCount];
        RandIndex = new List<int>();
        for (int count = 0; count < m_nCreatCount; count++)
        {
            m_lMonsters[count] = Instantiate(m_gCreatObj);
            m_lMonsters[count].transform.position = m_lCreatPos[ChoiceRand()].transform.position;
        }
        isSpon = true;
    }
    public bool StillAliveMon()
    {
        for (int count = 0; count < m_nCreatCount; count++)
        {
            if (m_lMonsters[count] != null)
                return true;
        }
        return false;
    }
}
