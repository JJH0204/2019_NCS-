﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*카메라가 플레이어를 추적해서 따라 다니도록 함
 * */
public class CarmeraTrak : MonoBehaviour
{
    public Player TrakTarget;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (TrakTarget == null) return;
        Vector3 vPos = this.transform.position;
        Vector3 vTargetPos = TrakTarget.transform.position;

        vTargetPos.z = vPos.z;

        Vector3 vDist = vTargetPos - vPos;
        Vector3 vDir = vDist.normalized;
        float fDist = vDist.magnitude;
        //Debug.Log("fDist : " + fDist);
        if (fDist > Time.deltaTime* (TrakTarget.GetSpeed() / 1.5f))
            transform.position += vDir * Time.deltaTime * (TrakTarget.GetSpeed() / 1.5f);
    }
}
