﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemManager : MonoBehaviour
{
    public GameObject ItemBox;
    public GameObject BoxPosition;
    GameObject Box;
    public bool isBoxRander;

    public ItemManager()
    {
        isBoxRander = false;

    }

    public void BoxRander()
    {
        if(isBoxRander == false)
        {
            Box = Instantiate(ItemBox);
            Box.transform.position = BoxPosition.transform.position;
            isBoxRander = true;
        }
    }
}
