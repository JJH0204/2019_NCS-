﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BlankSourceCode.AnimatedPixelPack2
{
    public class DataTag : MonoBehaviour 
	{
        // Editor Properties
        public string Tag;
    }
}